// 警情状态
export enum IncidentStatus {
    Pending = 0,
    InProgress = 1,
    Transfering = 2,
    HasTransfer = 3,
    Finished = 4,
}
