// 资源人
export class ResourcesPeople {
    resourcesId: string;
    resourcesName: string;
}
