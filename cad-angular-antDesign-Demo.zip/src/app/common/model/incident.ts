// 警情列表
export class Incident {
    id: string;
    phoneNumber: string;
    address: string;
    status: number;

    alarmName: string;
    incidentTime: string;
    description: string;
}
