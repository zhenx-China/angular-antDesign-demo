import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waiting-incident',
  templateUrl: './waiting-incident.component.html',
  styleUrls: ['./waiting-incident.component.css']
})
export class WaitingIncidentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
